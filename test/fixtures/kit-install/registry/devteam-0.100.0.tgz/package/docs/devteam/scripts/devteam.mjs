#!/usr/bin/env node
console.log('devteam 0.100.0 (a test fixture)');
