#!/usr/bin/env node
console.log('devteam 0.101.0 (a test fixture)');
