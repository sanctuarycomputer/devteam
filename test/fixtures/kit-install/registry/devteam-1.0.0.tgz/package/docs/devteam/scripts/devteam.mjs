#!/usr/bin/env node
// devteam-launcher: kit-package@1
console.log('devteam 1.0.0 (a test fixture)');
