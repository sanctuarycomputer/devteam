#!/usr/bin/env node
console.log('devteam 1.0.0 cli (a test fixture)');
