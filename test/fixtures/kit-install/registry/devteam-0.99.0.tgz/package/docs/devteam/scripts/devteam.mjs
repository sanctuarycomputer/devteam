#!/usr/bin/env node
console.log('devteam 0.99.0 (a test fixture)');
